module com.example.quantom_lab {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.quantom_lab to javafx.fxml;
    exports com.example.quantom_lab;
}