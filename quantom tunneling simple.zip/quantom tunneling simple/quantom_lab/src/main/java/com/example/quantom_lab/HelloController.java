package com.example.quantom_lab;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import java.util.ArrayList;
import java.util.Collections;

import java.util.ArrayList;

public class HelloController {

    public Circle particle;
    public HBox simulationArea;
    public StackPane square1;
    public Rectangle bar1;
    public StackPane square2;
    public Rectangle bar2;
    public StackPane square3;
    public Rectangle bar3;
    public StackPane square4;
    public Rectangle bar4;
    public StackPane square5;
    public Rectangle bar5;
    public StackPane square6;
    public Rectangle bar6;
    public StackPane square7;
    public Rectangle bar7;
    public StackPane square8;
    public Rectangle bar8;
    public StackPane square9;
    public Rectangle bar9;
    public StackPane square10;
    public Rectangle bar10;
    public Button runButton;
    public Button resetButton;
    public Button setbarsbtn;
    public Label titleText;
    public Label lessontxt;
    public Button evolvebtn;
    private ArrayList<Double> wavefunction=new ArrayList<>();
    private int indexofcollapse;

    private ArrayList<StackPane> squares = new ArrayList<>();
    private ArrayList<Rectangle> bars = new ArrayList<>();


    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    public void initialize() {
        setupFXMLArrays();
        System.out.println("start");
        setWavefunctionbarrier();
        setbars();





    }
    private void setupFXMLArrays() {
        squares.add(square1);
        squares.add(square2);
        squares.add(square3);
        squares.add(square4);
        squares.add(square5);
        squares.add(square6);
        squares.add(square7);
        squares.add(square8);
        squares.add(square9);
        squares.add(square10);
        bars.add(bar1);
        bars.add(bar2);
        bars.add(bar3);
        bars.add(bar4);
        bars.add(bar5);
        bars.add(bar6);
        bars.add(bar7);
        bars.add(bar8);
        bars.add(bar9);
        bars.add(bar10);
    }

    public void setWavefunctionbarrier(){
        wavefunction.clear();
        for(int i = 0; i < 10; i++){
            if (i<4){
                wavefunction.add(0.05);
            }else if (i<7){
                wavefunction.add(0.10);

            }else if (i<10){
                wavefunction.add(0.20);
            }
        }
        double sum=0;
        for (int i = 0; i < wavefunction.size(); i++) {
            System.out.println(wavefunction.get(i));
            sum+=wavefunction.get(i);
        }
        System.out.println(wavefunction.size());
        System.out.println(Integer.valueOf((int)(sum)));
    }

    public void evolvewave(){
        Collections.shuffle(wavefunction);
        lessontxt.setText("Now the wave evolved. this happens when the wave is not being observed. the probabilitys still equal 0 as i normalized it");
        for (int i = 0; i < wavefunction.size(); i++) {
            double adjusted = wavefunction.get(i);
            if (i < 4) adjusted -= 0.01;
            else if (i < 7) adjusted += 0.01;
            else if (i < 8) adjusted -= 0.03;
            else adjusted += 0.03;

            wavefunction.set(i, Math.max(0, adjusted)); // prevent negatives
        }
        normalizewave();
        setbars();


    }

    public void printwavefunction(){
        for (int i=0;i<wavefunction.size();i++){
            System.out.println(wavefunction.get(i));
        }
    }

    public void normalizewave(){
        double sum=0;
        for(int i =0;i<wavefunction.size();i++){
            sum+=wavefunction.get(i);
        }
        System.out.println("sum before "+ sum);
        for (int i=0;i<wavefunction.size();i++){
            wavefunction.set(i,wavefunction.get(i)/sum);
        }
        sum=0;
        for(int i =0;i<wavefunction.size();i++){
            sum+=wavefunction.get(i);
        }
        System.out.println("New sum "+sum);
    }

    public void wavefunctioncollapse(){
        lessontxt.setText("now bob observed the wave. it collapses from being everywhere to 1 place. its weighted but still random." + "\n"+"this is how tunneling works. theres always a non zero chance it could apear anywhere. if you have a barrier it just shrinks that chance"+"\n"+" but it can still apear. now that we are observing though theres a 100% chance its in 1 of them and 0% chance its in the other");
        indexofcollapse=-1;
        double rnum=Math.random();
        double runningSum=0;
        for (int j = 0; j < wavefunction.size(); j++) {
            runningSum += wavefunction.get(j);
            if (runningSum >= rnum) {
                indexofcollapse = j;
                break;
            }
        }
        System.out.println(indexofcollapse);
        printwavefunction();

        for (int i=0;i<wavefunction.size();i++){
            if (i==indexofcollapse){
                wavefunction.set(i,1.00);
            }else{
                wavefunction.set(i,0.00);
            }

        }
        printwavefunction();
    }
    public void setbars(){
        for (int i = 0; i < wavefunction.size(); i++) {
            double probability = wavefunction.get(i);
            bars.get(i).setHeight(probability * 200);
        }
    }





    public void handleResetButton(ActionEvent actionEvent) {
    }

    public void handleRunButton(ActionEvent actionEvent) {
        wavefunctioncollapse();
        setbars();

    }
}